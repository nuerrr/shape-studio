#include "GUI.h"
#include <iostream>
#include <fstream>
//#include "C:\Users\noura\Desktop\FINAL PHASE 1 - Copy\CMUgraphicsLib\colors.h"
#include "..\CMUgraphicsLib\colors.cpp"
#include "..\CMUgraphicsLib\colors.h"






using namespace std;
GUI::GUI()
{
	width = 1260;
	height = 600;
	wx = 5;
	wy = 5;

	toolbarmode = 1;
	

	StatusBarHeight = 50;
	ToolBarHeight = 50;
	MenuIconWidth = 70;

	DrawColor = BLACK;	  //default Drawing color
	FillColor = YELLOW;		  //default Filling color
	MsgColor = BLUE;		  //Messages color
	BkGrndColor = WHITE;	  //Background color
	HighlightColor = MAGENTA; //This color should NOT be used to draw shapes. use it for highlight only
	StatusBarColor = LIGHTSEAGREEN;
	PenWidth = 3;	//default width of the shapes frames

	//Create the output window
	pWind = CreateWind(width, height, wx, wy);
	//Change the title
	pWind->ChangeTitle("- - - - - - - - - - SHAPE STUDIO - - - - - - - - - -");

	CreateDrawToolBar();
	CreateStatusBar();
}

void GUI::set_FillColor()
{
	FillColor = color_var;
	is_Filled = true;
}
int GUI::get_resize()
{
	return resize;
}
void GUI::set_PenColor()
{
	DrawColor=color_var;
}
bool GUI::isFilled()
{
	return is_Filled;
}
/*
color GUI::get_color_var()
{
	return color_var;
}*/

//======================================================================================//
//								Input Functions										//
//======================================================================================//
void GUI::GetPointClicked(int& x, int& y) const
{
	pWind->WaitMouseClick(x, y);	//Wait for mouse click
}

string GUI::GetSrting() const
{
	string Label;
	char Key;
	keytype ktype;
	pWind->FlushKeyQueue();
	while (1)
	{
		ktype = pWind->WaitKeyPress(Key);
		if (ktype == ESCAPE )	//ESCAPE key is pressed
			return "";			//returns nothing as user has cancelled label
		if (Key == 13)			//ENTER key is pressed
			return Label;
		if (Key == 8)			//BackSpace is pressed
			if( Label.size() > 0)	
				Label.resize(Label.size() - 1);
			else
				Key = '\0';		
		else
			Label += Key;
		PrintMessage(Label);
	}
}

//This function reads the position where the user clicks to determine the desired operation
operationType GUI::GetUseroperation() // we will remove const from here but remember that cuz we might need to undo thisok
{
	int x, y;
	pWind->WaitMouseClick(x, y);	//Get the coordinates of the user click

	//[1] If user clicks on the Toolbar
	if (y >= 0 && y < ToolBarHeight)
	{
		//Check whick Menu icon was clicked
		//==> This assumes that menu icons are lined up horizontally <==
		int ClickedIconOrder = (x / MenuIconWidth);
		//Divide x coord of the point clicked by the menu icon width (int division)
		//if division result is 0 ==> first icon is clicked, if 1 ==> 2nd icon and so on
		//nou
		// //if its the main menu
		if(toolbarmode==1){ 
		switch (ClickedIconOrder)
		{
			//nou:
		case ICON_SHAPE:
			CreateShapesBar();
			break;
		case ICON_BACK:
			CreateDrawToolBar();
			break;
		case ICON_RESIZE:
			CreateResizeBar();
			break;
		/*case ICON_PALETTE:
			CreatePaletteBar();*/
			break;
		//noor
		case ICON_FILL:
			return CHNG_FILL_CLR;
			break;
		//noor
		case ICON_BRUSH:
			return CHNG_DRAW_CLR;
			break;
		//asmaa
		case ICON_SELECT:
			return SELECT;
			break;
		//nou
		case ICON_DELETE:
			return DEL;
			break; 
		case ICON_SAVE:
			return SAVE;
			break;
		case ICON_LOAD:
			return LOAD;
			break;
		case ICON_EXIT:
			return EXIT;
			break;
		case ICON_UNDO:
			return UNDO;
			break;
		case ICON_MOVE:
			return MOVE;
			break;

		case ICON_REDO:
			return REDO;
			break;
		case ICON_PASTE:
			return PASTE;
			break;
		case ICON_COPY:
			return COPY;
			break;
			/*case ICON_BACK2:
			CreateDrawToolBar();*/
			/*case ICON_BRUSH:
			opChangeDrawColor();
			break;
		case ICON_FILL:
			opChangeFillColor();
			break;*/
			/*case ICON_ROTATE:
			return ROTATE;
			break;

		case ICON_BACKWARD:
			return SEND_BACK;
			std::cout << "send back ";
			break;

		case ICON_STICK:
			return STICK;
			break;

		case ICON_PASTE:
			return PASTE;
			break;

		

		case ICON_LOAD:
			return LOAD;
			break;
		case ICON_DELETE:
			return DELETE;
			break;*/

		default: return EMPTY;	//A click on empty place in desgin toolbar
		}
	}
		else if (toolbarmode == 2) {
			switch (ClickedIconOrder)
			{
				//nou:
			case ICON_LINE:

				std::cout << "line ";
				return DRAW_LINE;
				break;
			case ICON_TRIANGLE:
				
				std::cout << "triangle  ";
				return DRAW_TRI;
				break;
			case ICON_SQUARE:

				return DRAW_RECT;
				break;
			case ICON_CIRCLE:

				std::cout << "circle ";
				return DRAW_CIRC;
				break;
			case ICON_OVAL:

				std::cout << "oval ";
				return DRAW_OVAL;
				break;
			case ICON_POLYGON:

				std::cout << "polygon ";
				return DRAW_POLY;
				break;


			case ICON_BACK:
				CreateDrawToolBar();
				break;
			}
		}
		else if (toolbarmode == 3) {
			switch (ClickedIconOrder)
			{
				//nou:
			case ICON_QUARTER:
				resize = 1;
				std::cout << "quarter ";
				return RESIZE;
				break;
			case ICON_HALF:
				resize = 2;
				std::cout << "half ";
				return RESIZE;
				break;
			case ICON_TWO:
				resize = 3;
				std::cout << "two ";
				return RESIZE;
				break;
			case ICON_FOUR:
				resize = 4;
				std::cout << "four ";
				return RESIZE;
				break;
			
			case ICON_BACK2:
				CreateDrawToolBar();
				break;
			}
		}
		else if (toolbarmode==4) {

			switch (ClickedIconOrder)
			{
				//nou:
			case ICON_WHITE:
				
				color_var = WHITE;
				break;
			case ICON_ORANGE:
				color_var = ORANGE;
				break;
			case ICON_YELLOW:

				color_var = YELLOW;
				break;
			case ICON_RED:
				color_var = RED;
				break;
			case ICON_GREEN:

				color_var = GREEN;
				break;
			case ICON_BLUE:

				color_var = BLUE;
				break;
			case ICON_PINK:
				color_var = PINK;
				break;
			case ICON_PURPLE:
				color_var = PURPLE;
				break;
			case ICON_BROWN:
				color_var = BROWN;
				break;
			case ICON_BLACK:
				color_var = BLACK;
				break;
			case ICON_BACK3:
				CreateDrawToolBar();
				
				break;


			default: return EMPTY;	//A click on empty place in desgin toolbar
			}
		}
	}

	//[2] User clicks on the drawing area
	if (y >= ToolBarHeight && y < height - StatusBarHeight)
	{
		return DRAWING_AREA;
	}

	//[3] User clicks on the status bar
	return STATUS;
}
////////////////////////////////////////////////////

//======================================================================================//
//								Output Functions										//
//======================================================================================//

window* GUI::CreateWind(int w, int h, int x, int y) const
{
	window* pW = new window(w, h, x, y);
	pW->SetBrush(BkGrndColor);
	pW->SetPen(BkGrndColor, 1);
	pW->DrawRectangle(0, ToolBarHeight, w, h);
	return pW;
}
//////////////////////////////////////////////////////////////////////////////////////////
void GUI::CreateStatusBar() const
{
	pWind->SetPen(StatusBarColor, 1);
	pWind->SetBrush(StatusBarColor);
	pWind->DrawRectangle(0, height - StatusBarHeight, width, height);
}
//////////////////////////////////////////////////////////////////////////////////////////
void GUI::ClearStatusBar() const
{
	//Clear Status bar by drawing a filled white rectangle
	pWind->SetPen(StatusBarColor, 1);
	pWind->SetBrush(StatusBarColor);
	pWind->DrawRectangle(0, height - StatusBarHeight, width, height);
}
////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////
void GUI::CreateDrawToolBar() 
{
	ClearToolBar();
	toolbarmode = 1;
	//You can draw the tool bar icons in any way you want.
	//Below is one possible way

	//First prepare List of images for each menu icon
	//To control the order of these images in the menu, 
	//reoder them in UI_Info.h ==> enum DrawMenuIcon

	string MenuIconImages[DRAW_ICON_COUNT];

	MenuIconImages[ICON_SHAPE] = "images\\MenuIcons\\shape.jpg";
	MenuIconImages[ICON_BRUSH] = "images\\MenuIcons\\brush.jpg";
	MenuIconImages[ICON_FILL] = "images\\MenuIcons\\fill.jpg";
  //MenuIconImages[ICON_PALETTE] = "images\\MenuIcons\\palette.jpg";
	MenuIconImages[ICON_SELECT] = "images\\MenuIcons\\select.jpg";
	MenuIconImages[ICON_RESIZE] = "images\\MenuIcons\\resize.jpg";
	MenuIconImages[ICON_ROTATE] = "images\\MenuIcons\\rotate.jpg";
	MenuIconImages[ICON_BACKWARD] = "images\\MenuIcons\\backward.jpg";
	MenuIconImages[ICON_STICK] = "images\\MenuIcons\\stick.jpg";
	MenuIconImages[ICON_COPY] = "images\\MenuIcons\\copy.jpg";
	MenuIconImages[ICON_PASTE] = "images\\MenuIcons\\paste.jpg";
	MenuIconImages[ICON_UNDO] = "images\\MenuIcons\\undo.jpg";
	MenuIconImages[ICON_REDO] = "images\\MenuIcons\\redo.jpg";
	MenuIconImages[ICON_SAVE] = "images\\MenuIcons\\save.jpg";
	MenuIconImages[ICON_LOAD] = "images\\MenuIcons\\load.jpg";
	MenuIconImages[ICON_MOVE] = "images\\MenuIcons\\move.jpg";
	MenuIconImages[ICON_DELETE] = "images\\MenuIcons\\delete.jpg";
	MenuIconImages[ICON_EXIT] = "images\\MenuIcons\\exit.jpg";
    //MenuIconImages[ICON_RECT] = "images\\MenuIcons\\Menu_Rect.jpg";
	//MenuIconImages[ICON_TRI] = "images\\MenuIcons\\Menu_Tri.jpg";
	//nuIconImages[ICON_EXIT] = "images\\MenuIcons\\Menu_Exit.jpg";

	//TODO: Prepare images for each menu icon and add it to the list

	//Draw menu icon one image at a time
	for (int i = 0; i < DRAW_ICON_COUNT; i++)
		pWind->DrawImage(MenuIconImages[i], i * MenuIconWidth, 0, MenuIconWidth, ToolBarHeight);

	//Draw a line under the toolbar
	//pWind->SetPen(BLACK, 3);
	//pWind->DrawLine(0, ToolBarHeight, width, ToolBarHeight);

	DrawToolBarLine();
}
//////////////////////////////////////////////////////////////////////////////////////////

//nou:
void GUI::CreateShapesBar()
{
	ClearToolBar();
	toolbarmode = 2;
	string ShapeIconImages[SHAPE_COUNT];

	ShapeIconImages[ICON_LINE] = "images\\ShapeIcons\\line.jpg";
	ShapeIconImages[ICON_TRIANGLE] = "images\\ShapeIcons\\triangle.jpg";
	ShapeIconImages[ICON_SQUARE] = "images\\ShapeIcons\\square.jpg";
	ShapeIconImages[ICON_CIRCLE] = "images\\ShapeIcons\\circle.jpg";
	ShapeIconImages[ICON_OVAL] = "images\\ShapeIcons\\oval.jpg";
	ShapeIconImages[ICON_POLYGON] = "images\\ShapeIcons\\polygon.jpg";
	ShapeIconImages[ICON_BACK] = "images\\ShapeIcons\\back.jpg";

	for (int i = 0; i < SHAPE_COUNT; i++)
		pWind->DrawImage(ShapeIconImages[i], i * MenuIconWidth, 0, MenuIconWidth, ToolBarHeight);

	DrawToolBarLine();
}

void GUI::CreateResizeBar()  {
	toolbarmode = 3;
	ClearToolBar();

	string ResizeIconImages[RESIZE_COUNT];

	ResizeIconImages[ICON_QUARTER] = "images\\ResizeIcons\\quarter.jpg";
	ResizeIconImages[ICON_HALF] = "images\\ResizeIcons\\half.jpg";
	ResizeIconImages[ICON_TWO] = "images\\ResizeIcons\\two.jpg";
	ResizeIconImages[ICON_FOUR] = "images\\ResizeIcons\\four.jpg";
	ResizeIconImages[ICON_BACK2] = "images\\ResizeIcons\\back.jpg";
	
	for (int i = 0; i < RESIZE_COUNT; i++)
		pWind->DrawImage(ResizeIconImages[i], i * MenuIconWidth, 0, MenuIconWidth, ToolBarHeight);

	DrawToolBarLine();
}

void GUI::CreatePaletteBar()
{
	ClearToolBar();
	toolbarmode = 4;
	string PaletteIconImages[PALETTE_COUNT];
	
	PaletteIconImages[ICON_WHITE] = "images\\PaletteIcons\\white.jpg";
	PaletteIconImages[ICON_ORANGE] = "images\\PaletteIcons\\orange.jpg";
	PaletteIconImages[ICON_YELLOW] = "images\\PaletteIcons\\yellow.jpg";
	PaletteIconImages[ICON_RED] = "images\\PaletteIcons\\red.jpg";
	PaletteIconImages[ICON_GREEN] = "images\\PaletteIcons\\green.jpg";
	PaletteIconImages[ICON_BLUE] = "images\\PaletteIcons\\blue.jpg";
	PaletteIconImages[ICON_PINK] = "images\\PaletteIcons\\pink.jpg";
	PaletteIconImages[ICON_PURPLE] = "images\\PaletteIcons\\purple.jpg";
	PaletteIconImages[ICON_BROWN] = "images\\PaletteIcons\\brown.jpg";
	PaletteIconImages[ICON_BLACK] = "images\\PaletteIcons\\black.jpg";
	PaletteIconImages[ICON_BACK3] = "images\\PaletteIcons\\back.jpg";

	for (int i = 0; i < PALETTE_COUNT; i++)
		pWind->DrawImage(PaletteIconImages[i], i * MenuIconWidth, 0, MenuIconWidth, ToolBarHeight+2);

	DrawToolBarLine();
}

//nou

void GUI::save(ofstream& myFile)
{
	
	//ofstream myFile("shape.txt");
	string COLOR;
	string COLOR2;


	if (DrawColor == WHITE) {
		COLOR = "WHITE";
	}
	else if (DrawColor == ORANGE) {
		COLOR = "ORANGE";
	}
	else if (DrawColor == YELLOW) {
		COLOR = "YELLOW";
	}
	else if (DrawColor == RED) {
		COLOR = "RED";
	}
	else if (DrawColor == GREEN) {
		COLOR = "GREEN";
	}
	else if (DrawColor == BLUE) {
		COLOR = "BLUE";
	}
	else if (DrawColor == PINK) {
		COLOR = "PINK";
	}
	else if (DrawColor == PURPLE) {
		COLOR = "PURPLE";
	}
	else if (DrawColor == BROWN) {
		COLOR = "BROWN";
	}
	else if (DrawColor == BLACK) {
		COLOR = "BLACK";
	}

	myFile << COLOR << " ";

	if (FillColor == WHITE) {
		COLOR2 = "WHITE";
	}
	else if (FillColor == ORANGE) {
		COLOR2 = "ORANGE";
	}
	else if (FillColor == YELLOW) {
		COLOR2 = "YELLOW";
	}
	else if (FillColor == RED) {
		COLOR2 = "RED";
	}
	else if (FillColor == GREEN) {
		COLOR2 = "GREEN";
	}
	else if (FillColor == BLUE) {
		COLOR2 = "BLUE";
	}
	else if (FillColor == PINK) {
		COLOR2 = "PINK";
	}
	else if (FillColor == PURPLE) {
		COLOR2 = "PURPLE";
	}
	else if (FillColor == BROWN) {
		COLOR2 = "BROWN";
	}
	else if (FillColor == BLACK) {
		COLOR2 = "BLACK";
	}

	myFile << COLOR2 << " ";
	//if (PenWidth==3){
	//	PENWIDTH = "3";
	//}

	myFile << PenWidth << " ";

	
}

void GUI:: load(ifstream& myFile) {

	string colorStr;
	string fillColorStr;



	myFile >> colorStr;
	if (colorStr == "WHITE") {
		DrawColor = WHITE;
	}
	else if (colorStr == "ORANGE") {
		DrawColor = ORANGE;
	}
	else if (colorStr == "YELLOW") {
		DrawColor = YELLOW;
	}
	else if (colorStr == "RED") {
		DrawColor = RED;
	}
	else if (colorStr == "GREEN") {
		DrawColor = GREEN;
	}
	else if (colorStr == "BLUE") {
		DrawColor = BLUE;
	}
	else if (colorStr == "PINK") {
		DrawColor = PINK;
	}
	else if (colorStr == "PURPLE") {
		DrawColor = PURPLE;
	}
	else if (colorStr == "BROWN") {
		DrawColor = BROWN;
	}
	else if (colorStr == "BLACK") {
		DrawColor = BLACK;
	}

	myFile >> fillColorStr;
	if (fillColorStr == "WHITE") {
		FillColor = WHITE;
	}
	else if (fillColorStr == "ORANGE") {
		FillColor = ORANGE;
	}
	else if (fillColorStr == "YELLOW") {
		FillColor = YELLOW;
	}
	else if (fillColorStr == "RED") {
		FillColor = RED;
	}
	else if (fillColorStr == "GREEN") {
		FillColor = GREEN;
	}
	else if (fillColorStr == "BLUE") {
		FillColor = BLUE;
	}
	else if (fillColorStr == "PINK") {
		FillColor = PINK;
	}
	else if (fillColorStr == "PURPLE") {
		FillColor = PURPLE;
	}
	else if (fillColorStr == "BROWN") {
		FillColor = BROWN;
	}
	else if (fillColorStr == "BLACK") {
		FillColor = BLACK;
	}


	
	//Graph* pGraph = pControl->getGraph();
	//pGraph->load(myFile, numShapes);
}


//nou:
void GUI::ClearToolBar() const
{
	pWind->SetPen(BkGrndColor, 1);
	pWind->SetBrush(BkGrndColor);
	pWind->DrawRectangle(0, 0, width, ToolBarHeight+2);
}

void GUI::DrawToolBarLine()const {
	pWind->SetPen(BLACK, 3);
	pWind->DrawLine(0, ToolBarHeight+3, width, ToolBarHeight+3);
}

void GUI::ClearDrawArea() const
{
	pWind->SetPen(BkGrndColor, 1);
	pWind->SetBrush(BkGrndColor);
	pWind->DrawRectangle(0, ToolBarHeight+6, width, height - StatusBarHeight);
}
//////////////////////////////////////////////////////////////////////////////////////////

void GUI::PrintMessage(string msg) const	//Prints a message on status bar
{
	ClearStatusBar();	//First clear the status bar

	pWind->SetPen(MsgColor, 50);
	pWind->SetFont(24, BOLD, BY_NAME, "Arial");
	pWind->DrawString(10, height - (int)(0.75 * StatusBarHeight), msg);
}
//////////////////////////////////////////////////////////////////////////////////////////

color GUI::getCrntDrawColor() const	//get current drwawing color
{
	return DrawColor;
}
//////////////////////////////////////////////////////////////////////////////////////////

color GUI::getCrntFillColor() const	//get current filling color
{
	return FillColor;
}
//////////////////////////////////////////////////////////////////////////////////////////

int GUI::getCrntPenWidth() const		//get current pen width
{
	return PenWidth;
}

window* GUI::Get_wind()
{
	return pWind;
}

//======================================================================================//
//								shapes Drawing Functions								//
//======================================================================================//

void GUI::DrawRect(Point P1, Point P2, GfxInfo RectGfxInfo) const
{
	color DrawingClr;
	if (RectGfxInfo.isSelected)	     //shape is selected
		DrawingClr = HighlightColor; //shape should be drawn highlighted
	else
		DrawingClr = RectGfxInfo.DrawClr;

	pWind->SetPen(DrawingClr, RectGfxInfo.BorderWdth);	//Set Drawing color & width

	drawstyle style;
	if (RectGfxInfo.isFilled)
	{
		style = FILLED;
		pWind->SetBrush(RectGfxInfo.FillClr);
	}
	else
		style = FRAME;

	pWind->DrawRectangle(P1.x, P1.y, P2.x, P2.y, style);
}
//noor 
void GUI::DrawLine(Point P1, Point P2, GfxInfo LineGfxInfo) const
{
	color DrawingClr;
	
	if(LineGfxInfo.isSelected)	     //shape is selected
		DrawingClr = HighlightColor; //shape should be drawn highlighted
	else
		DrawingClr = LineGfxInfo.DrawClr;

	pWind->SetPen(DrawingClr, LineGfxInfo.BorderWdth);	//Set Drawing color & width

	drawstyle style;
	style = FRAME;
	

	pWind->DrawLine(P1.x, P1.y, P2.x, P2.y, style);
}

void GUI::DrawCircle(Point P1, int r, GfxInfo CircleGfxInfo) const
{
	color DrawingClr;

	if (CircleGfxInfo.isSelected)	     //shape is selected
		DrawingClr = HighlightColor; //shape should be drawn highlighted
	else
		DrawingClr = CircleGfxInfo.DrawClr;
	pWind->SetPen(DrawingClr, CircleGfxInfo.BorderWdth);	//Set Drawing color & width

	drawstyle style;
	if (CircleGfxInfo.isFilled)
	{
		style = FILLED;
		pWind->SetBrush(CircleGfxInfo.FillClr);
	}
	else
		style = FRAME;

	//double r=sqrt((P1.x-P2.x)* (P1.x - P2.x)+ (P1.y - P2.y)* (P1.y - P2.y));//get the radius from two points

	pWind->DrawCircle(P1.x, P1.y,r, style);
}

//noor
void GUI::DrawPolygon(int X[], int Y[], GfxInfo PolyGfxInfo) const
{
	color DrawingClr;

	if (PolyGfxInfo.isSelected)	     //shape is selected
		DrawingClr = HighlightColor; //shape should be drawn highlighted
	else
		DrawingClr = PolyGfxInfo.DrawClr;
	pWind->SetPen(DrawingClr, PolyGfxInfo.BorderWdth);	//Set Drawing color & width

	drawstyle style;

	if (PolyGfxInfo.isFilled)
	{
		style = FILLED;
		pWind->SetBrush(PolyGfxInfo.FillClr);
	}
	else
		style = FRAME;

	pWind->DrawPolygon(X, Y, 6, style);
}
void GUI::DrawOval(Point center, int length, int height, GfxInfo OvalGfxInfo) const
{
	color DrawingClr;
	if (OvalGfxInfo.isSelected)	     //shape is selected
		DrawingClr = HighlightColor; //shape should be drawn highlighted
	else
		DrawingClr = OvalGfxInfo.DrawClr;

	pWind->SetPen(DrawingClr, OvalGfxInfo.BorderWdth);	//Set Drawing color & width
	
	drawstyle style;

	if (OvalGfxInfo.isFilled)
	{
		style = FILLED;
		pWind->SetBrush(OvalGfxInfo.FillClr);
	}
	else
		style = FRAME;

	pWind->DrawEllipse(center.x - length, center.y - height, center.x + length, center.y + height, style);
}


void GUI::DrawTri(Point P1, Point P2, Point P3,GfxInfo RectGfxInfo) const
{
	color DrawingClr;
	if (RectGfxInfo.isSelected)	     //shape is selected
		DrawingClr = HighlightColor; //shape should be drawn highlighted
	else
		DrawingClr = RectGfxInfo.DrawClr;

	pWind->SetPen(DrawingClr, RectGfxInfo.BorderWdth);	//Set Drawing color & width

	drawstyle style;
	if (RectGfxInfo.isFilled)
	{
		style = FILLED;
		pWind->SetBrush(RectGfxInfo.FillClr);
	}
	else
		style = FRAME;

	pWind->DrawTriangle(P1.x, P1.y, P2.x, P2.y,P3.x,P3.y, style);
}
//////////////////////////////////////////////////////////////////////////////////////////

GUI::~GUI()
{
	delete pWind;
}

