#pragma once

#include "..\CMUgraphicsLib\CMUgraphics.h"
#include "..\Defs.h"

#include <string>

using namespace std;

struct Point	    //To be used for shapes points
{ 
	int x, y;
};

struct GfxInfo	   //Graphical info common for all shapes (you may add more members)
{
	color DrawClr;		//Draw color of the shape
	color FillClr;		//Fill color of the shape
	bool isFilled;		//shape Filled or not
	int BorderWdth;		//Width of shape borders
	bool isSelected;	//true if the shape is selected.
};

class GUI
{
	//nou: 
	int toolbarmode; //make a variable for the tool bar and initiate it in the constructor
	enum MenuIcon //The icons of the menu (you should add more icons)
	{
		//Note: Icons are ordered here as they appear in menu
		//If you want to change the menu icons order, change the order here
		ICON_SHAPE,
		ICON_BRUSH,
		ICON_FILL,
		//ICON_PALETTE,
		ICON_SELECT,
		ICON_MOVE,
		ICON_RESIZE,
		ICON_ROTATE,
		ICON_BACKWARD,
		ICON_STICK,
		ICON_COPY,
		ICON_PASTE,
		ICON_UNDO,
		ICON_REDO,
		ICON_SAVE,
		ICON_LOAD,
		ICON_DELETE,
		ICON_EXIT,
		//ICON_RECT,		//Recangle icon in menu
		//ICON_TRI,		    //Triangle icon in menu

		//TODO: Add more icons names here

		//ICON_EXIT,		//Exit icon

		DRAW_ICON_COUNT		//no. of menu icons ==> This should be the last line in this enum
	};
	
	enum ShapeIcon {

		ICON_LINE,
		ICON_TRIANGLE,
		ICON_SQUARE,
		ICON_CIRCLE,
		ICON_OVAL,
		ICON_POLYGON,

		ICON_BACK,

		SHAPE_COUNT
	};

	enum ResizeIcon {

		ICON_QUARTER,
		ICON_HALF,
		ICON_TWO,
		ICON_FOUR,
		
		ICON_BACK2,

		RESIZE_COUNT
	};

	enum PaletteIcon {

		ICON_WHITE,
		ICON_ORANGE,
		ICON_YELLOW,
		ICON_RED,
		ICON_GREEN,
		ICON_BLUE,
		ICON_PINK,
		ICON_PURPLE,
		ICON_BROWN,
		ICON_BLACK,

		ICON_BACK3,

		PALETTE_COUNT
	};

	int	width, height,	    //Window width and height
		wx, wy,			    //Window starting coordinates
		StatusBarHeight,	//Status Bar Height
		ToolBarHeight,		//Tool Bar Height (distance from top of window to bottom line of toolbar)
		MenuIconWidth;		//Width of each icon in toolbar menu
	//nou
	color color_var;
	int resize;
	//
	color DrawColor;		//Drawing color
	color FillColor;		//Filling color
	color HighlightColor;	//Highlighting color
	color MsgColor;			//Messages color
	color BkGrndColor;		//Background color
	color StatusBarColor;	//Status bar color
	int PenWidth;			//width of the pen that draws shapes
	bool is_Filled;
	/// Add more members if needed 

	window* pWind;
	 
public:

	GUI();
	void set_FillColor();
	int get_resize();
	void set_PenColor();
	bool isFilled();
	// Input Functions  ---------------------------
	void GetPointClicked(int& x, int& y) const; //Get coordinate where user clicks
	string GetSrting() const;				    //Returns a string entered by the user
	operationType GetUseroperation();	    //Read the user click and map to an operation

	// Output Functions  ---------------------------
	window* CreateWind(int, int, int, int) const; //creates the application window
	void CreateDrawToolBar();				  //creates Draw mode toolbar & menu
	void CreateStatusBar() const;				  //create the status bar

	//nou:
	void CreateShapesBar() ; //made it const because the getuseroperation() is const
	void CreateResizeBar() ;
	void CreatePaletteBar();
	void save(ofstream& myFile);
	void load(ifstream& myFile);



	void ClearToolBar() const;
	void ClearStatusBar() const ;	//Clears the status bar
	void ClearDrawArea() const;	    //Clears the drawing area

	void DrawToolBarLine() const;

	// -- shapes Drawing functions
	void DrawRect(Point P1, Point P2, GfxInfo RectGfxInfo) const;  //Draw a rectangle
	void DrawLine(Point P1, Point P2, GfxInfo LineGfxInfo) const;
	void DrawTri(Point P1, Point P2, Point P3, GfxInfo TriGfxInfo) const; 
	void DrawCircle(Point P1, int r, GfxInfo TriGfxInfo) const;
	void DrawPolygon(int[] , int[] , GfxInfo PolyGfxInfo) const;
	void DrawOval(Point center, int length, int height, GfxInfo ElliGfxInfo) const;
	///Make similar functions for drawing all other shapes.

	void PrintMessage(string msg) const;	//Print a message on Status bar

	color getCrntDrawColor() const; 	//get current drwawing color
	color getCrntFillColor() const;	    //get current filling color
	int getCrntPenWidth() const;		//get current pen width

	window* Get_wind();
	
	~GUI();
};

