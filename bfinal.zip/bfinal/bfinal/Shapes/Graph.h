#pragma once
#include "Shape.h"
#include <fstream>

using namespace std;

//forward decl
class GUI;	

//A class that is responsible on everything related to shapes
class Graph
{
	enum { maxShapeCount = 1000 };
private:
	shape* shapesList[maxShapeCount]; //a container to hold all shapes	
	shape* shapesList2[maxShapeCount]; //a container to hold all shapes	for the second time
	shape* shapesList3[maxShapeCount]; //a container to hold all shapes	for the second time
	int shapeCount;			// Actual number of shapes stored in the list
	int shapeCount2;			// Actual number of shapes stored in the list
	int shapeCount3;			// Actual number of shapes stored in the list
	shape* copied;			//copied shape
	shape* selectedShape;	//pointer to the currently selected shape
public:										
	Graph();
	~Graph();
	void clearshapelist();
	shape* get_selectedshape();
	void Addshape(shape* pFig); //Adds a new shape to the shapesList
	void Draw(GUI* pUI) const;			//Draw the graph (draw all shapes)
	shape* Getshape(int x, int y) ; //Search for a shape given a point inside the shape
	void UnselectAll();
	void Save(ofstream&);	//Save all shapes to a file
	void load(ifstream& inputfile);	//Load all shapes from a file

	void delete_selected_shape();

	void update();
	void undo();
	void redo();

	void copy();
	shape* return_copied();
	void paste(Point);

	color string_to_color(string);
	void deleteShape();
	void exit();
};
