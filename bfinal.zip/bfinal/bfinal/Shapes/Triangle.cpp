#include "Triangle.h"




Triangle::Triangle(Point P1, Point P2,Point P3, GfxInfo shapeGfxInfo) :shape(shapeGfxInfo)
{
	Corner1 = P1;
	Corner2 = P2;
	corner3 = P3;
}

Triangle::~Triangle()
{
}

void Triangle::Draw(GUI* pUI) const
{
	//Call Output::DrawRect to draw a rectangle on the screen	
	pUI->DrawTri(Corner1, Corner2,corner3, ShpGfxInfo);
}

//asmaa
bool Triangle::IsPointInside(Point p) const
{
	// Function to calculate the area of a triangle given its vertices
	auto area = [](Point a, Point b, Point c) -> double {
		return std::abs((a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y)) / 2.0);
		};

	// Calculate the area of the triangle ABC
	double A = area(Corner1, Corner2, corner3);

	// Calculate the area of the triangle PAB, PBC and PCA
	double A1 = area(p, Corner1, Corner2);
	double A2 = area(p, Corner2, corner3);
	double A3 = area(p, corner3, Corner1);

	// Check if the sum of A1, A2 and A3 is the same as A
	return (A == A1 + A2 + A3);
}

void Triangle::PrintInfo(GUI* pUI) const
{
	string msg = "YOU SELECTED A TRIANGLE AND ITS COORDINATES ARE X1:" + to_string(Corner1.x) + " Y1:" + to_string(Corner1.y) + " X2:" + to_string(Corner2.x) + " Y2:" + to_string(Corner1.y)+ " X3:" + to_string(corner3.x) + " Y3:" + to_string(corner3.y);
	pUI->PrintMessage(msg);

}

void Triangle::Save(ofstream& myFile, int num) {
	myFile << "\nTRIANGLE " << to_string(num) << " " << to_string(Corner1.x) << " " << to_string(Corner1.y) << " " << to_string(Corner2.x) << " " << to_string(Corner2.y) <<" " << to_string(corner3.x) << " " << to_string(corner3.y) << " " << color_return(ShpGfxInfo.DrawClr) << " " << color_return(ShpGfxInfo.FillClr);
}

void Triangle::Resize(int x)
{

    //THIS IS SAME CONCEPT AS THE LINE RESIZE IF YOU DONT UNDERSTAND LOOK AT THE LINE RESIZE

    // Calculate the CENTER of the triangle
    Point center;
    center.x = (Corner1.x + Corner2.x + corner3.x) / 3;
    center.y = (Corner1.y + Corner2.y + corner3.y) / 3;

    // Calculate the current size of the triangle by averaging the distances from the centroid to the vertices
    double currentSize = (sqrt(pow(Corner1.x - center.x, 2) + pow(Corner1.y - center.y, 2)) +
        sqrt(pow(Corner2.x - center.x, 2) + pow(Corner2.y - center.y, 2)) +
        sqrt(pow(corner3.x - center.x, 2) + pow(corner3.y - center.y, 2))) / 3;

    double newSize;
    switch (x) {
    case 1:
        newSize = currentSize * 0.5;
        break;
    case 2:
        newSize = currentSize * sqrt(0.5);
        break;
    case 3:
        newSize = currentSize * sqrt(2);
        break;
    case 4:
        newSize = currentSize * 2;
        break;
    case 0:
        return;
    }

    // Calculate the scaling factor SAME AS LINEEEE
    double scaleFactor = newSize / currentSize;

    //SAME AS LINE AAAAAAAAAAAAAAAAA
    // Scale each vertex relative to the CENTER
    Corner1.x = center.x + (Corner1.x - center.x) * scaleFactor;
    Corner1.y = center.y + (Corner1.y - center.y) * scaleFactor;

    Corner2.x = center.x + (Corner2.x - center.x) * scaleFactor;
    Corner2.y = center.y + (Corner2.y - center.y) * scaleFactor;

    corner3.x = center.x + (corner3.x - center.x) * scaleFactor;
    corner3.y = center.y + (corner3.y - center.y) * scaleFactor;
   


}

void Triangle::Move(Point x)
{
    Point center;
    center.x = (Corner1.x + Corner2.x + corner3.x) / 3;
    center.y = (Corner1.y + Corner2.y + corner3.y) / 3;

    // Calculate the translation vector (difference between new point and centroid)
    int dx = x.x - center.x;
    int dy = x.y - center.y;

    // Move each corner by the translation vector
    Corner1.x += dx;
    Corner1.y += dy;

    Corner2.x += dx;
    Corner2.y += dy;

    corner3.x += dx;
    corner3.y += dy;
}



 Triangle* Triangle::clone() const
{
    return new Triangle(*this); // Use the copy constructor
}


