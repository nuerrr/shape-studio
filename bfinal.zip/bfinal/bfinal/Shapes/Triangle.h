#pragma once

#include "shape.h"


class Triangle : public shape
{
private:
	Point Corner1;
	Point Corner2;
	Point corner3;
public:
	Triangle(Point, Point, Point, GfxInfo shapeGfxInfo); 
	virtual ~Triangle();
	virtual void Draw(GUI* pUI) const;
	virtual bool IsPointInside(Point p) const override;
	virtual void PrintInfo(GUI* pUI) const override;
	virtual void Save(ofstream& OutFile, int) override;
	virtual void Resize(int) override;//SAME CONCEPT AS THE LINE BUT WITH THREE POINTTTTTTTTTSSSSSSS

	virtual void Move(Point)override;

	virtual Triangle* clone() const override;
};