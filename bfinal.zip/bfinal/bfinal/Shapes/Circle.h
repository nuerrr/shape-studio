#pragma once

#include "shape.h"


class Circle : public shape
{
private:
	Point Corner1;
	Point Corner2;
	int radius;
public:
	Circle(Point, Point, GfxInfo shapeGfxInfo);
	virtual ~Circle();
	virtual void Draw(GUI* pUI) const;
	virtual bool IsPointInside(Point p) const override;
	virtual void PrintInfo(GUI* pUI) const override;
	virtual void Save(ofstream& OutFile, int);
	virtual void Resize(int) override;
	virtual Circle* clone() const override;

	virtual void Move(Point)override;

};