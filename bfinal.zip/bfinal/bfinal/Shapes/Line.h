#pragma once

#include "shape.h"


//noor
class Line : public shape
{
private:
	Point Corner1;
	Point Corner2;
public:
	Line(Point, Point, GfxInfo shapeGfxInfo);
	virtual ~Line();
	virtual void Draw(GUI* pUI) const;
	virtual bool IsPointInside(Point p) const override;
	virtual void PrintInfo(GUI* pUI) const override;
	virtual void Save(ofstream& OutFile, int) override;
	virtual void Resize(int) override;

	virtual Line* clone() const override;
	virtual void Move(Point)override;

};
