#include "shape.h"
#include <fstream>

shape::shape(GfxInfo shapeGfxInfo)
{ 
	ShpGfxInfo = shapeGfxInfo;	//Default status is non-filled.
}
 
void shape::SetSelected(bool s)
{	ShpGfxInfo.isSelected = s; }

bool shape::IsSelected() const
{	return ShpGfxInfo.isSelected; }

//nou
string shape::color_return(color x)
{
    
    if (x == WHITE) {
        return "WHITE";
    }
    else if (x == ORANGE) {
        return "ORANGE";
    }
    else if (x == YELLOW) {
        return "YELLOW";
    }
    else if (x == RED) {
        return "RED";
    }
    else if (x == GREEN) {
        return "GREEN";
    }
    else if (x == BLUE) {
        return "BLUE";
    }
    else if (x == PINK) {
        return "PINK";
    }
    else if (x == PURPLE) {
        return "PURPLE";
    }
    else if (x == BROWN) {
        return "BROWN";
    }
    else if (x == BLACK) {
        return "BLACK";
    }

   

}

void shape::ChngDrawClr(color Dclr)
{	ShpGfxInfo.DrawClr = Dclr; }

void shape::ChngFillClr(color Fclr)
{	
	ShpGfxInfo.isFilled = true;
	ShpGfxInfo.FillClr = Fclr; 
}



