#include "Graph.h"
#include "../GUI/GUI.h"
#include<iostream>
#include "..\shapes\Rect.h"
#include "..\shapes\Circle.h"
#include "..\shapes\Line.h"
#include "..\shapes\Triangle.h"
#include "..\shapes\Polygon.h"
#include "..\shapes\Oval.h"


using namespace std;

Graph::Graph()
{
	shapeCount = 0;
	selectedShape = nullptr;
	copied = nullptr;
}

Graph::~Graph()
{
}

void Graph::clearshapelist()
{
	for (int i = 0; i < shapeCount; i++) {
		shapesList[i] = nullptr;
	}
	shapeCount = 0;	
}

shape* Graph::get_selectedshape()
{
	return selectedShape;
}

//==================================================================================//
//						shapes Management Functions								//
//==================================================================================//

//Add a shape to the list of shapes
void Graph::Addshape(shape* pShp)
{
	//Add a new shape to the shapes list
	if(shapeCount<maxShapeCount)
		shapesList[shapeCount++] = pShp;
}
////////////////////////////////////////////////////////////////////////////////////
//Draw all shapes on the user interface
void Graph::Draw(GUI* pUI) const
{
	pUI->ClearDrawArea();
	for (int i = 0; i < shapeCount; i++) {
	if (shapesList[i])
		shapesList[i]->Draw(pUI);
}
}


shape* Graph::Getshape(int x, int y) 
{
	Point p = { x,y };
	// Iterate through the shapes in the list
	for (int i = 0; i < shapeCount; ++i)  // Use shapeCount to avoid going out of bounds
	{

		shape* shp = shapesList[i];
		if (shp == nullptr) {
			// Skip null shapes (safety check)
			continue;
		}
		if (shp->IsPointInside(p))  // Assuming IsPointInside() method exists in shape class
		{
			selectedShape = shp;
			return shp;  // Return the shape if point is inside
		}
	}
	return nullptr;  // Return nullptr if no shape contains the point
}

void Graph::UnselectAll()
{
	
	for (int i=0;i<shapeCount;i++)
	{
		shapesList[i]->SetSelected(false);
	}
}

void Graph::Save(ofstream& myFile)
{
	//ofstream myFile("shape.txt");
	myFile << shapeCount;

	for (int i = 0; i < shapeCount; i++) {
		if (shapesList[i] != nullptr) {
			shapesList[i]->Save(myFile, i+1);
		}
	}
	

	
}

void Graph::load(ifstream& myFile)
{	
	GfxInfo information;

	int numShapes;	
	int penWidth;
	myFile >> penWidth;
	myFile >> numShapes;
	std::cout << numShapes;
	string name;
	int id, polylen, oval_h,oval_l;
	Point I, II, III;
	//int x1, y1, x2, y2, x3, y3;
	string draw, fill;
	clearshapelist();
	while (!myFile.eof()) {
		myFile >> name;
		cout << name;
		if (name == "TRIANGLE") {
			myFile >> id >> I.x >> I.y >> II.x >> II.y >> III.x >> III.y >> draw >> fill;

			information.DrawClr = string_to_color(draw);
			information.FillClr = string_to_color(fill);
			information.isFilled = true;
			information.isSelected = false;
			information.BorderWdth = penWidth;

			Triangle* T = new Triangle(I,II,III,information);
			Addshape(T);

			
			//pUI->DrawTri(I,II,III,information);
		}
		else if(name=="LINE"){
			myFile >> id >> I.x >> I.y >> II.x >> II.y>>draw >> fill;

			information.DrawClr = string_to_color(draw);
			information.FillClr = string_to_color(fill);
			information.isFilled = true;
			information.isSelected = false;
			information.BorderWdth = penWidth;

			Line* L = new Line(I, II, information);
			Addshape(L);


			
		}
		else if (name == "CIRCLE") {
			myFile >> id >> I.x >> I.y >> II.x >> II.y >> draw >> fill;

			information.DrawClr = string_to_color(draw);
			information.FillClr = string_to_color(fill);
			information.isFilled = true;
			information.isSelected = false;
			information.BorderWdth = penWidth;

			Circle* C = new Circle(I, II, information);
			Addshape(C);
			
		}
		else if (name == "RECTANGLE") {
			myFile >> id >> I.x >> I.y >> II.x >> II.y >> draw >> fill;

			information.DrawClr = string_to_color(draw);
			information.FillClr = string_to_color(fill);
			information.isFilled = true;
			information.isSelected = false;
			information.BorderWdth = penWidth;

			Rect* R = new Rect(I, II, information);
			Addshape(R);
		}
		else if (name == "POLYGON") {
			myFile >> id >> I.x >> I.y >> polylen>> draw >> fill;

			information.DrawClr = string_to_color(draw);
			information.FillClr = string_to_color(fill);
			information.isFilled = true;
			information.isSelected = false;
			information.BorderWdth = penWidth;

			Poly* P = new Poly(I, polylen, information);
			Addshape(P);
		}
		else if (name == "OVAL") {
			myFile >> id >> I.x >> I.y >> oval_h>>oval_l >> draw >> fill;

			information.DrawClr = string_to_color(draw);
			information.FillClr = string_to_color(fill);
			information.isFilled = true;
			information.isSelected = false;
			information.BorderWdth = penWidth;

			Oval* O = new Oval(I, oval_l,oval_h, information);
			Addshape(O);
		}
		
		
	}
	
}
void Graph::delete_selected_shape()
{
	//delete selectedShape;
	selectedShape = nullptr;
	//selectedShape = new shape;
}
void Graph::update()
{
	shapeCount2 = shapeCount;
	shapeCount3 = 0;

	for (int i = 0; i < shapeCount; i++) {
		if (shapesList[i] != nullptr) {
			shapesList2[i] = shapesList[i]->clone(); // Deep copy using clone method
		}
		else {
			shapesList2[i] = nullptr;
		}
		shapesList3[i] = nullptr;
	}
	
}
//nou
void Graph::undo()
{
	shapeCount3 = shapeCount;
	shapeCount = shapeCount2;

	for (int i = 0; i < maxShapeCount; i++) {
		shapesList3[i] = shapesList[i];
		shapesList[i] = shapesList2[i];
		
	}
}
void Graph::redo()
{
	shapeCount = shapeCount3;
	for (int i = 0; i < maxShapeCount; i++) {
		shapesList[i] = shapesList3[i];

	}

}
void Graph::copy()
{
	shape* temp = selectedShape->clone();
	copied = temp;
}
shape* Graph::return_copied()
{
	return copied;
}
void Graph::paste(Point x)
{
	if (copied != nullptr) {
        shape* newShape = copied->clone();  
        copied = nullptr;  
        newShape->Move(x);  
        Addshape(newShape); 
        selectedShape = newShape;
    }
}
//nou
color Graph::string_to_color(string str) {
	if (str == "WHITE") {
		return WHITE;
	}
	else if (str == "ORANGE") {
		return ORANGE;
	}
	else if (str == "YELLOW") {
		return YELLOW;
	}
	else if (str == "RED") {
		return RED;
	}
	else if (str == "GREEN") {
		return GREEN;
	}
	else if (str == "BLUE") {
		return BLUE;
	}
	else if (str == "PINK") {
		return PINK;
	}
	else if (str == "PURPLE") {
		return PURPLE;
	}
	else if (str == "BROWN") {
		return BROWN;
	}
	else if (str == "BLACK") {
		return BLACK;
	}
}


//nou
void Graph::deleteShape()
{
	

	for (int i = 0; i < shapeCount; i++) {
		if (shapesList[i] == selectedShape) {
			shapesList[i]->SetSelected(false);
			delete shapesList[i];
			shapesList[i] = nullptr;

			for (int j = i; j < shapeCount - 1; j++) {
				shapesList[j] = shapesList[j + 1];
			}
			shapesList[shapeCount - 1] = nullptr;  // Set last element to nullptr
			shapeCount--;
			selectedShape = nullptr;  // Reset selected shape

			break;
		}
	}

	
}

void Graph::exit()
{
	for (int i = 0; i < shapeCount; i++) {
		delete shapesList[i];
		shapesList[i] = nullptr;
	}

	if (selectedShape) {
		selectedShape = nullptr;
	}
	


//	delete shapesList;            // Deallocate the memory
	//shapesList = nullptr;

}
