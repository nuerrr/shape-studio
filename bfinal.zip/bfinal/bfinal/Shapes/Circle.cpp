#include "Circle.h"





Circle::Circle(Point P1, Point P2, GfxInfo shapeGfxInfo) :shape(shapeGfxInfo)
{
	Corner1 = P1;
	Corner2 = P2;
	radius = sqrt((Corner1.x - Corner2.x) * (Corner1.x - Corner2.x) + (Corner1.y - Corner2.y) * (Corner1.y - Corner2.y));

}

Circle::~Circle()
{
}

void Circle::Draw(GUI* pUI) const
{
	pUI->DrawCircle(Corner1, radius, ShpGfxInfo);
}





bool Circle::IsPointInside(Point p) const
{
	// Calculate the radius using the center and the boundary point
	int dx = Corner2.x - Corner1.x;
	int dy = Corner2.y - Corner1.y;
	int radius = static_cast<int>(sqrt(dx * dx + dy * dy));

	// Calculate the distance from the point p to the center
	dx = p.x - Corner1.x;
	dy = p.y - Corner1.y;

	// Check if the point is inside the circle
	return (dx * dx + dy * dy <= radius * radius);

}

void Circle::PrintInfo(GUI* pUI) const
{
	string msg = "YOU SELECTED A CIRCLE AND ITS COORDINATES ARE CENTER X1:" + to_string(Corner1.x) + " Y1:" + to_string(Corner1.y) + " RADIUS: " + to_string(radius);
	pUI->PrintMessage(msg);
}


void Circle::Save(ofstream& myFile, int num) {
	myFile << "\nCIRCLE " << to_string(num) << " " << to_string(Corner1.x) << " " << to_string(Corner1.y) << " " << to_string(Corner2.x) << " " << to_string(Corner2.y) << " " << color_return(ShpGfxInfo.DrawClr) << " " << color_return(ShpGfxInfo.FillClr);

}

void Circle::Resize(int x)
{
	switch (x) {
	case 1:
		size = 1;
		radius = radius * 0.5;
		break;

	case 2:
		size = 2;
		radius *= sqrt(0.5);
		break;
	case 3:
		size = 3;
		radius *= sqrt(2);
		break;
	case 4:
		size = 4;
		radius *= 2;
		break;
	case 0:
		size = 0;
		break;
	}
}

Circle* Circle::clone() const
{
	return new Circle(*this); // Use the copy constructor
}

void Circle::Move(Point x)
{
	Corner1 = x;
}
