#pragma once

#include "shape.h"


class Oval : public shape
{
private:
	Point Center, P;
	int length;
	int height;
public:
	Oval(Point, int, int, GfxInfo shapeGfxInfo);
	virtual ~Oval();
	virtual void Draw(GUI* pUI) const;
	virtual bool IsPointInside(Point p) const override;
	virtual void PrintInfo(GUI* pUI) const override;
	virtual void Save(ofstream& OutFile, int) override;
	virtual void Resize(int) override;//SAME CONCEPT AS THE LINE BUT WITH THREE POINTTTTTTTTTSSSSSSS
	virtual Oval* clone() const override;
	virtual void Move(Point)override;

};