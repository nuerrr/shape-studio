#pragma once

#include "shape.h"


class Poly : public shape
{
private:
	Point Center, P;
	int length;
	int* X = new int[6];
	int* Y= new int[6];
	Point vertices[6];
public:
	//array of X points and Y points andpoint and length
	Poly(Point C, int len, GfxInfo shapeGfxInfo);
	virtual ~Poly();
	virtual void Draw(GUI* pUI) const;
	virtual bool IsPointInside(Point p) const override;
	bool IsPointInsideTriangle(Point p, Point a, Point b, Point c) const;// a function to see if a point is inside a triangle to then see it for each triangle in a polygon
	virtual void PrintInfo(GUI* pUI) const override;
	virtual void Save(ofstream& OutFile, int) override;
	virtual void Resize(int) override;
	void calc_vertix();

	virtual Poly* clone() const override;
	virtual void Move(Point)override;
};