#include "Rect.h"

Rect::Rect(Point P1, Point P2, GfxInfo shapeGfxInfo):shape(shapeGfxInfo)
{
	Corner1 = P1;
	Corner2 = P2;
}

Rect::~Rect()
{}

void Rect::Draw(GUI* pUI) const
{
	//Call Output::DrawRect to draw a rectangle on the screen	
	pUI->DrawRect(Corner1, Corner2, ShpGfxInfo);
	
}
bool Rect::IsPointInside(Point p) const
{
	//check if the coordinates of the point are between the corners
	return (p.x >= Corner1.x && p.x <= Corner2.x && p.y >= Corner1.y && p.y <= Corner2.y);
}

void Rect::PrintInfo(GUI* pUI) const
{
	string msg = "YOU SELECTED A RECTANGLE AND ITS COORDINATES ARE X1:" + to_string(Corner1.x) + " Y1:" + to_string(Corner1.y) + " X2:" + to_string(Corner2.x) + " Y2:" + to_string(Corner1.y);
	pUI->PrintMessage(msg);
	
}
//nou

void Rect::Save(ofstream& myFile, int num) {


	myFile << "\nRECTANGLE " << to_string(num) << " " << to_string(Corner1.x )<< " " <<	to_string(Corner1.y) << " " << to_string(Corner2.x) << " " << to_string(Corner2.y )<< " " << color_return(ShpGfxInfo.DrawClr) << " " << color_return(ShpGfxInfo.FillClr);
}

void Rect::Resize(int x)
{
    //THIS CODE IS THE SAME CODE AS THE RESIZE OF THE LINE CUZ IT IS THE SAME CONCEPT JUST EXTENDING THE DIAGONALSSSSSS AAAAAAAAAAAA
    // Calculate the center point of the line
    Point center;
    center.x = (Corner1.x + Corner2.x) / 2;
    center.y = (Corner1.y + Corner2.y) / 2;

    // Calculate the current length of the line
    double currentLength = sqrt(pow(Corner2.x - Corner1.x, 2) + pow(Corner2.y - Corner1.y, 2));

    // Resize the line based on the provided size
    double newLength;
    switch (x) {
    case 1:
        newLength = currentLength * 0.5;
        break;
    case 2:
        newLength = currentLength * sqrt(0.5);
        break;
    case 3:
        newLength = currentLength * sqrt(2);
        break;
    case 4:
        newLength = currentLength * 2;
        break;
    case 0:
        return; // No change in size
    default:
        return; // Invalid size
    }
    // Calculate the scaling factor
    double scaleFactor = newLength / currentLength;

    // Scale the corner points around the center
    Corner1.x = center.x + (Corner1.x - center.x) * scaleFactor;
    Corner1.y = center.y + (Corner1.y - center.y) * scaleFactor;
    Corner2.x = center.x + (Corner2.x - center.x) * scaleFactor;
    Corner2.y = center.y + (Corner2.y - center.y) * scaleFactor;
}

Rect* Rect::clone() const
{
    return new Rect(*this); // Use the copy constructor
}

void Rect::Move(Point newCenter)
{
    Point currentCenter;
    currentCenter.x = (Corner1.x + Corner2.x) / 2;
    currentCenter.y = (Corner1.y + Corner2.y) / 2;

    int dx = newCenter.x - currentCenter.x;
    int dy = newCenter.y - currentCenter.y;

    Corner1.x += dx;
    Corner1.y += dy;
    Corner2.x += dx;
    Corner2.y += dy;
}
