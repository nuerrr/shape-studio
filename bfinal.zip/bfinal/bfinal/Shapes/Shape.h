#pragma once
#include "..\defs.h"
#include "..\GUI\GUI.h"
#include<fstream>


//Base class for all shapes
class shape
{
protected:
	int ID;		//Each shape has an ID
	GfxInfo ShpGfxInfo;	//shape graphis info

	/// Add more parameters if needed.
	int size;
public:
	shape(GfxInfo shapeGfxInfo);
	virtual ~shape() {}
	void SetSelected(bool s);	//select/unselect the shape yes
	bool IsSelected() const;	//check whether fig is selected
	string color_return(color);
	virtual void Draw(GUI* pUI) const  = 0 ;		//Draw the shape
	
	void ChngDrawClr(color Dclr);	//changes the shape's drawing color
	void ChngFillClr(color Fclr);	//changes the shape's filling color

	//nou
	virtual void Save(ofstream& OutFile, int) = 0;

	///The following functions should be supported by the shape class
	///It should be overridden by each inherited shape

	///Decide the parameters that you should pass to each function	


	//virtual void Rotate() = 0;	//Rotate the shape
	virtual void Resize(int) = 0;	//Resize the shape
	virtual void Move(Point) = 0;		//Move the shape
	virtual shape* clone() const = 0;

	virtual void  PrintInfo(GUI* pUI)const = 0 ;	//print all shape info on the status bar///Output* pOut
	virtual bool IsPointInside(Point p) const = 0;
};

