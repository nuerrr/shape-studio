#include "Polygon.h"
#include<cmath>



Poly::Poly(Point center, int SideLength, GfxInfo shapeGfxInfo) :shape(shapeGfxInfo)
{
	Center = center;
	length = SideLength;
	calc_vertix();
}

Poly::~Poly()
{
}

void Poly::Draw(GUI* pUI) const
{
	//Call Output::DrawRect to draw a polygon on the screen	
	pUI->DrawPolygon(X, Y, ShpGfxInfo);
}

//asmaa
bool Poly::IsPointInside(Point p) const
{
	// Function to calculate the area of a triangle given its vertices
	for (int i = 0; i < 6; i++) {
		if (IsPointInsideTriangle(p, vertices[0], vertices[(i) % 6], vertices[(i + 1) % 6])) {
			return true;
		}
	}
	return false;
}


bool Poly::IsPointInsideTriangle(Point p, Point a, Point b, Point c) const
{
	auto area = [](Point a, Point b, Point c) -> double {
		return std::abs((a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y)) / 2.0);
		};

	// Calculate the area of the triangle ABC
	double A = area(a, b, c);

	// Calculate the area of the triangle PAB, PBC and PCA
	double A1 = area(p, a, b);
	double A2 = area(p, b, c);
	double A3 = area(p, c, a);

	// Check if the sum of A1, A2 and A3 is the same as A
	return (A == A1 + A2 + A3);
}

void Poly::PrintInfo(GUI* pUI) const
{
	string msg = "YOU SELECTED A Polygon AND ITS Center ARE X1:" + to_string(Center.x) + " Y1:" + to_string(Center.y) + " And its Radius is" + to_string(length);
	pUI->PrintMessage(msg);

}

void Poly::Save(ofstream& myFile, int num) {
	myFile << "\nPOLYGON " << to_string(num) << " " << to_string(Center.x) << " " << to_string(Center.y) << " " << to_string(length) << " " << color_return(ShpGfxInfo.DrawClr) << " " << color_return(ShpGfxInfo.FillClr);
}

void Poly::Resize(int x)
{
	switch (x) {
	case 1:
		size = 1;
		length = length * 0.5;
		break;

	case 2:
		size = 2;
		length *= sqrt(0.5);
		break;
	case 3:
		size = 3;
		length *= sqrt(2);
		break;
	case 4:
		size = 4;
		length *= 2;
		break;
	case 0:
		size = 0;
		break;
	}
	calc_vertix();
}

void Poly::calc_vertix()
{
	vertices[0].x = Center.x - length;
	vertices[0].y = Center.y;

	vertices[1].x = Center.x - length / 2;
	vertices[1].y = Center.y - (length - length / 20 * 3);

	vertices[2].x = Center.x + length / 2;
	vertices[2].y = Center.y - (length - length / 20 * 3);

	vertices[3].x = Center.x + length;
	vertices[3].y = Center.y;

	vertices[4].x = Center.x + length / 2;
	vertices[4].y = Center.y + (length - length / 20 * 3);

	vertices[5].x = Center.x - length / 2;
	vertices[5].y = Center.y + (length - length / 20 * 3);



	for (int i = 0; i < 6; i++)
	{
		X[i] = vertices[i].x;
		Y[i] = vertices[i].y;
	}
}

Poly* Poly::clone() const
{
	return new Poly(*this); // Use the copy constructor
}

void Poly::Move(Point newCenter) {// Calculate the translation vector
	int dx = newCenter.x - Center.x;
	int dy = newCenter.y - Center.y;

	// Update the center of the polygon
	Center.x = newCenter.x;
	Center.y = newCenter.y;

	// Translate each vertex by the translation vector
	for (int i = 0; i < 6; ++i)
	{
		vertices[i].x += dx;
		vertices[i].y += dy;
	}

	// Recalculate the X and Y arrays after moving
	for (int i = 0; i < 6; ++i)
	{
		X[i] = vertices[i].x;
		Y[i] = vertices[i].y;
	}
}

