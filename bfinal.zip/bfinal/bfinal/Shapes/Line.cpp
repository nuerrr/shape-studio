#include "Line.h"



//noor 
Line::Line(Point P1, Point P2, GfxInfo shapeGfxInfo) :shape(shapeGfxInfo)
{
	Corner1 = P1;
	Corner2 = P2;
}

Line::~Line()
{
}

void Line::Draw(GUI* pUI) const
{
	//Call Output::DrawRect to draw a rectangle on the screen	
	pUI->DrawLine(Corner1, Corner2, ShpGfxInfo);
}



bool Line::IsPointInside(Point p) const
{
    {
        //we will make it select within a range of 2px around the line

        double lineLength = sqrt(pow(Corner2.x - Corner1.x, 2) + pow(Corner2.y - Corner1.y, 2));

        if (lineLength == 0) {
            double distance = sqrt(pow(p.x - Corner1.x, 2) + pow(p.y - Corner1.y, 2));
            return distance <= 2.0; // 2px margin
        }

        // Normalize the line vector
        double dx = (Corner2.x - Corner1.x) / lineLength;
        double dy = (Corner2.y - Corner1.y) / lineLength;
        double px = p.x - Corner1.x;
        double py = p.y - Corner1.y;

        // visualize the line
        double projection = dx * px + dy * py;
        if (projection < 0) {
            double distance = sqrt(pow(p.x - Corner1.x, 2) + pow(p.y - Corner1.y, 2));
            return distance <= 2.0; // 2px margin
        }
        else if (projection > lineLength) {
            double distance = sqrt(pow(p.x - Corner2.x, 2) + pow(p.y - Corner2.y, 2));
            return distance <= 2.0; // 2px margin
        }

        double projX = Corner1.x + projection * dx;
        double projY = Corner1.y + projection * dy;

        // distance from the visualized line with distance 2px
        double distance = sqrt(pow(p.x - projX, 2) + pow(p.y - projY, 2));
        return distance <= 2.0; // 2px margin
    }
}
void Line::PrintInfo(GUI* pUI) const
{
	//
}
//nou


void Line::Save(ofstream& myFile, int num) {
	myFile << "\nLINE " << to_string(num) << " " << to_string(Corner1.x) << " " << to_string(Corner1.y) << " " << to_string(Corner2.x) << " " << to_string(Corner2.y) << " " << color_return(ShpGfxInfo.DrawClr) << " " << color_return(ShpGfxInfo.FillClr);


}

void Line::Resize(int x)
{
    // Calculate the center point of the line
    Point center;
    center.x = (Corner1.x + Corner2.x) / 2;
    center.y = (Corner1.y + Corner2.y) / 2;

    // Calculate the current length of the line
    double currentLength = sqrt(pow(Corner2.x - Corner1.x, 2) + pow(Corner2.y - Corner1.y, 2));

    // Resize the line based on the provided size
    double newLength;
    switch (x) {
    case 1:
        newLength = currentLength * 0.5;
        break;
    case 2:
        newLength = currentLength * sqrt(0.5);
        break;
    case 3:
        newLength = currentLength * sqrt(2);
        break;
    case 4:
        newLength = currentLength * 2;
        break;
    case 0:
        return; // No change in size
    default:
        return; // Invalid size
    }
    // Calculate the scaling factor
    double scaleFactor = newLength / currentLength;

    // Scale the corner points around the center
    Corner1.x = center.x + (Corner1.x - center.x) * scaleFactor;
    Corner1.y = center.y + (Corner1.y - center.y) * scaleFactor;
    Corner2.x = center.x + (Corner2.x - center.x) * scaleFactor;
    Corner2.y = center.y + (Corner2.y - center.y) * scaleFactor;
}

Line* Line::clone() const
{
    return new Line(*this); // Use the copy constructor
}

void Line::Move(Point newPos)
{
    // Calculate the midpoint of the line
    Point midpoint;
    midpoint.x = (Corner1.x + Corner2.x) / 2;
    midpoint.y = (Corner1.y + Corner2.y) / 2;

    // Calculate the translation vector
    int dx = newPos.x - midpoint.x;
    int dy = newPos.y - midpoint.y;

    // Translate both endpoints of the line
    Corner1.x += dx;
    Corner1.y += dy;

    Corner2.x += dx;
    Corner2.y += dy;
    
}
