#include "Oval.h"




Oval::Oval(Point P1, int x,int y, GfxInfo shapeGfxInfo) :shape(shapeGfxInfo)
{
    Center = P1;
    height = x;
    length = y;
}

Oval::~Oval()
{
}

void Oval::Draw(GUI* pUI) const
{
	//Call Output::DrawRect to draw a rectangle on the screen	
	pUI->DrawOval(Center, length,height, ShpGfxInfo);
}

//asmaa
bool Oval::IsPointInside(Point p) const
{
	// Calculate the horizontal and vertical radii
	double a = length / 2.0; // Half of the total length (horizontal radius)
	double b = height / 2.0; // Half of the total height (vertical radius)

	// Calculate the distance from the center to the point in terms of the ellipse equation
	double dx = static_cast<double>(p.x - Center.x);
	double dy = static_cast<double>(p.y - Center.y);

	// Apply the ellipse equation to check if the point is inside
	double ellipseEquation = (dx * dx) / (a * a) + (dy * dy) / (b * b);

	return ellipseEquation <= 1.0;
	
}

void Oval::PrintInfo(GUI* pUI) const
{
    string msg = "YOU SELECTED AN OVAL AND ITS CENTER IS X1:" + to_string(Center.x) + " Y1:" + to_string(Center.y) + "and the length is:" + to_string(length) + " and heigth:" + to_string(height);
	pUI->PrintMessage(msg);

}

void Oval::Save(ofstream& myFile, int num) {
	myFile << "\nOVAL " << to_string(num) << " " << to_string(Center.x) << " " << to_string(Center.y) << " " << to_string(length) << " " << to_string(height) << " "<< color_return(ShpGfxInfo.DrawClr) << " " << color_return(ShpGfxInfo.FillClr);
}

void Oval::Resize(int x)
{

    //THIS IS SAME CONCEPT AS THE CIRCLE RESIZE IF YOU DONT UNDERSTAND LOOK AT THE LINE RESIZE

	switch (x) {
	case 1:
		size = 1;
		length= length * 0.5;
		height= height* 0.5;
		break;

	case 2:
		size = 2;
		length *= sqrt(0.5);
		height *= sqrt(0.5);
		break;
	case 3:
		size = 3;
		length *= sqrt(2);
		height *= sqrt(2);
		break;
	case 4:
		size = 4;
		length *= 2;
		height *= 2;
		break;
	case 0:
		size = 0;
		break;
	}


}

Oval* Oval::clone() const
{
	return new Oval(*this); // Use the copy constructor
}

void Oval::Move(Point newCenter)
{
	int dx = newCenter.x - Center.x;
	int dy = newCenter.y - Center.y;

	Center.x += dx;
	Center.y += dy;
}


