#include "controller.h"


int main()
{

	//Create an object of controller
	controller Control;

	Control.Run();

	
	return 0;
}

