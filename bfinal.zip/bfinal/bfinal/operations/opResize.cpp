#include "opResize.h"

#include "..\controller.h"

#include "..\GUI\GUI.h"



opResize::opResize(controller* pCont) : operation(pCont) {
	GUI* pUI = pControl->GetUI();
	int F = pUI->get_resize();
	resize_factor = F;
}

opResize::~opResize() {}

void opResize::Execute()
{
	//Point p;
	GUI* pUI = pControl->GetUI();
	Graph* pGraph = pControl->getGraph();

	pGraph->update();

	if (!pGraph->get_selectedshape()) {
	pUI->PrintMessage("NO SHAPE SELECTED");
	}
	else if (resize_factor == 1) {
		pUI->PrintMessage("RESIZE BY 0.25X");
		pGraph->get_selectedshape()->Resize(resize_factor);
	}
	else if (resize_factor == 2) {
		pUI->PrintMessage("RESIZE BY 0.5X");
		pGraph->get_selectedshape()->Resize(resize_factor);
	}
	else if (resize_factor == 3) {
		pUI->PrintMessage("RESIZE BY 2X");
		pGraph->get_selectedshape()->Resize(resize_factor);
	}
	else if (resize_factor == 4) {
		pUI->PrintMessage("RESIZE BY 4X");
		pGraph->get_selectedshape()->Resize(resize_factor);
	}// Check if a shape is clicked and select/deselect it
	

	pUI->ClearDrawArea();
	pGraph->Draw(pUI);


}
