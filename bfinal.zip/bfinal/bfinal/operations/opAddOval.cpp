#include "opAddOval.h"
#include "..\shapes\Oval.h"

#include "..\controller.h"

#include "..\GUI\GUI.h"
#include<cmath>


opAddOval::opAddOval(controller* pCont) :operation(pCont)
{}
opAddOval::~opAddOval()
{}


void opAddOval::Execute()
{
	Point C, P1, P2;

	//Get a Pointer to the Interface
	GUI* pUI = pControl->GetUI();

	pUI->PrintMessage("New Oval: Click at first corner");
	//Read 1st corner and store in point P1
	pUI->GetPointClicked(C.x, C.y);

	string msg = "Center is at (" + to_string(C.x) + ", " + to_string(C.y) + " )";
	msg += " Set the Height";
	pUI->PrintMessage(msg);
	//Read 2nd corner and store in point P2
	pUI->GetPointClicked(P1.x, P1.y);

	msg = "Height is at (" + to_string(P1.x) + ", " + to_string(P1.y) + " )";
	msg += " Set the Length";
	pUI->PrintMessage(msg);
	//Read 2nd corner and store in point P2
	pUI->GetPointClicked(P2.x, P2.y);
	pUI->ClearStatusBar();

	GfxInfo OvalGfxInfo;

	//get drawing, filling colors and pen width from the interface
	OvalGfxInfo.DrawClr = pUI->getCrntDrawColor();
	OvalGfxInfo.FillClr = pUI->getCrntFillColor();
	OvalGfxInfo.BorderWdth = pUI->getCrntPenWidth();


	OvalGfxInfo.isFilled = pUI->isFilled();;	//default is not filled
	OvalGfxInfo.isSelected = false;	//defualt is not selected

	int hieght=sqrt((C.x - P1.x) * (C.x - P1.x) + (C.y - P1.y) * (C.y - P1.y));
	int length=sqrt((C.x - P2.x) * (C.x - P2.x) + (C.y - P2.y) * (C.y - P2.y));

	Oval* O = new Oval(C, length, hieght, OvalGfxInfo);


	Graph* pGr = pControl->getGraph();

	//Add the Oval to the list of shapes
	pGr->update();
	pGr->Addshape(O);

	//Step 5 - print new figure info in status bar
	O->PrintInfo(pUI);

}


