#pragma once

#include "operation.h"


class opPaste : public operation
{
public:
	opPaste(controller* pCont);
	virtual ~opPaste();

	//Add line to the controller
	virtual void Execute();

};
