#include "opRedo.h"
#include "..\controller.h"
#include "..\GUI\GUI.h"


opRedo::opRedo(controller* pCont) :operation(pCont){}
opRedo::~opRedo()
{}

//Execute the operation
void opRedo::Execute()
{
	Graph* pGraph = pControl->getGraph();
	GUI* pUI = pControl->GetUI();



	pGraph->redo();


	string msg = " You have Redone the last operation";

	pUI->PrintMessage(msg);

	
}