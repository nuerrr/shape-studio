#include "opChangeColor.h"
//#include "..\shapes\Rect.h"

#include "..\controller.h"

#include "..\GUI\GUI.h"


opChangeColor::opChangeColor(controller* pCont) :operation(pCont)
{}
opChangeColor::~opChangeColor()
{}

//Execute the operation
void opChangeColor::Execute()
{

	//Get a Pointer to the Input / Output Interfaces
	GUI* pUI = pControl->GetUI();



	string msg = "you wil change the fill color now, choose a color";
	pUI->PrintMessage(msg);

	pUI->CreatePaletteBar();
	pUI->GetUseroperation();
	pUI->set_FillColor();

	//Preapre all rectangle parameters
	//GfxInfo TRIGfxInfo;

	//get drawing, filling colors and pen width from the interface 
	//TRIGfxInfo.DrawClr = pUI->getCrntDrawColor();
	//TRIGfxInfo.FillClr = pUI->get_color_var();
	//pUI change color

	//TRIGfxInfo.isFilled = false;	//default is not filled
	//TRIGfxInfo.isSelected = false;	//defualt is not selected 


}