#include "opPaste.h"

#include "..\controller.h"

#include "..\GUI\GUI.h"
#include<cmath>


opPaste::opPaste(controller* pCont) :operation(pCont)
{}
opPaste::~opPaste()
{}


void opPaste::Execute()
{
	Point P;

	//Get a Pointer to the Input / Output Interfaces 
	GUI* pUI = pControl->GetUI();
	Graph* pGr = pControl->getGraph();

	if (pGr->return_copied()!=nullptr) {
		pUI->PrintMessage("YOU CLICKED PASTE CLICK ON A COORDINATE ON THE GRAPH TO PASTE YOUR SHAPE");
		pUI->GetPointClicked(P.x, P.y);
		pGr->update();
		pGr->paste(P);
	}
	else
	pUI->PrintMessage("YOU CLICKED ON PASTE WITH NO COPIED SHAPEEEEEEE");

}


