#include "opSave.h"
#include "..\controller.h"
#include "..\GUI\GUI.h"


opSave::opSave(controller* pCont) :operation(pCont){}
opSave::~opSave()
{}

//Execute the operation
void opSave::Execute()
{
	ofstream myFile("shape.txt");

	GUI* pUI = pControl->GetUI();
	pUI->save(myFile);
	pUI->PrintMessage("GRAPH SAVED TO 'shape.txt'");

	Graph* pGraph = pControl->getGraph();
	pGraph->Save(myFile);

	
}