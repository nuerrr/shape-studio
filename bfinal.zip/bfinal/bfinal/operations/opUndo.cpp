#include "opUndo.h"
#include "..\controller.h"
#include "..\GUI\GUI.h"


opUndo::opUndo(controller* pCont) :operation(pCont){}
opUndo::~opUndo()
{}

//Execute the operation
void opUndo::Execute()
{

	Graph* pGraph = pControl->getGraph();
	GUI* pUI = pControl->GetUI();

	

		pGraph->undo();


		string msg = " You have Undone the last operation";

		pUI->PrintMessage(msg);
	
}