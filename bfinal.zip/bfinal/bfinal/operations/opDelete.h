#pragma once

#include "operation.h"

//nou
//class opDelete : public operation
//{
//public:
//	opDelete(controller* pCont);
//	virtual ~opDelete();
//
//	// Execute selection operation
//	virtual void�Execute();
//};

class opDelete : public operation
{
public:
	opDelete(controller* pCont);
	virtual ~opDelete();

	// Execute delete operation
	virtual void Execute() override;  // Ensure this matches the base class signature
};
