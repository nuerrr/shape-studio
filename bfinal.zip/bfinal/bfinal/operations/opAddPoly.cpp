#include "opAddPoly.h"
#include "..\shapes\Polygon.h"

#include "..\controller.h"

#include "..\GUI\GUI.h"
#include<cmath>


opAddPolygon::opAddPolygon(controller* pCont) :operation(pCont)
{}
opAddPolygon::~opAddPolygon()
{}


void opAddPolygon::Execute()
{
	Point center, P2;

	//Get a Pointer to the Input / Output Interfaces 
	GUI* pUI = pControl->GetUI();

	pUI->PrintMessage("New Poly: Click at Center");
	//Read 1st corner and store in point P1
	pUI->GetPointClicked(center.x, center.y);

	string msg = "Center is at (" + to_string(center.x) + ", " + to_string(center.y) + " )";
	msg += " ... Click at Vertix";
	pUI->PrintMessage(msg);
	//Read 2nd corner and store in point P2
	pUI->GetPointClicked(P2.x, P2.y);
	pUI->ClearStatusBar();

	//Preapre all Circle parameters
	GfxInfo PolyGfxInfo;

	//get drawing, filling colors and pen width from the interface
	PolyGfxInfo.DrawClr = pUI->getCrntDrawColor();
	PolyGfxInfo.FillClr = pUI->getCrntFillColor();
	PolyGfxInfo.BorderWdth = pUI->getCrntPenWidth();
	
	
	PolyGfxInfo.isFilled = pUI->isFilled();;	//default is not filled
	PolyGfxInfo.isSelected = false;	//defualt is not selected

	int SideLength = sqrt((center.x - P2.x) * (center.x - P2.x) + (center.y - P2.y) * (center.y - P2.y));

	//


	//Create a polygon with the above parameters
	Poly* P = new Poly(center,SideLength, PolyGfxInfo);

	//Get a pointer to the graph
	Graph* pGr = pControl->getGraph();

	//Add the rectangle to the list of shapes
	pGr->update();
	pGr->Addshape(P);

}


