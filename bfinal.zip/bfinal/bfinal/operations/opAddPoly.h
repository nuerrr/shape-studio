#pragma once

#include "operation.h"


class opAddPolygon: public operation
{
public:
	opAddPolygon(controller* pCont);
	virtual ~opAddPolygon();

	//Add line to the controller
	virtual void Execute();

};
