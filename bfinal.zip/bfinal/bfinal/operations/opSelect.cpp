#include "opSelect.h"

#include "..\controller.h"

#include "..\GUI\GUI.h"


opSelect::opSelect(controller* pCont) : operation(pCont) {}

opSelect::~opSelect() {}

void opSelect::Execute()
{
	Point p;
	GUI* pUI = pControl->GetUI();
	Graph* pGraph = pControl->getGraph();

	pUI->PrintMessage("Click on shape to select/unselect");

	//Get the point clicked
	pUI->GetPointClicked(p.x, p.y);



	// Check if a shape is clicked and select/deselect it
	shape* clickedShape = pGraph->Getshape(p.x, p.y);

	if (clickedShape != NULL)
	{
		if (pGraph->get_selectedshape()) {

			if (clickedShape->IsSelected()) {
				pGraph->delete_selected_shape();
				pGraph->UnselectAll();
				pUI->ClearStatusBar();
			}
			else {
				pGraph->UnselectAll();
				clickedShape->SetSelected(true);
				clickedShape->PrintInfo(pUI);
			}

		}
	}
	else
	{
		pGraph->delete_selected_shape();
		pGraph->UnselectAll();
		pUI->ClearStatusBar();

	}

	pUI->ClearDrawArea();
	pGraph->Draw(pUI);


}
