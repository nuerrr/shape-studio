#include "opCopy.h"

#include "..\controller.h"

#include "..\GUI\GUI.h"
#include<cmath>


opCopy::opCopy(controller* pCont) :operation(pCont)
{}
opCopy::~opCopy()
{}


void opCopy::Execute()
{
	Point center, P2;

	//Get a Pointer to the Input / Output Interfaces 
	GUI* pUI = pControl->GetUI();
	Graph* pGraph = pControl->getGraph();
	
	if (pGraph->get_selectedshape()) {
		
		pGraph->copy();
		pUI->PrintMessage("COPY DONE");

	}
	else
		pUI->PrintMessage("NO SELECTED SHAPE");

	

}


