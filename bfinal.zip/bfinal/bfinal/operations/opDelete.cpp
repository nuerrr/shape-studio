#include "opDelete.h"
//#include "..\shapes\Rect.h"

#include "..\controller.h"

#include "..\GUI\GUI.h"




//nou

opDelete::opDelete(controller* pCont) : operation(pCont) {}

opDelete::~opDelete() {}

void opDelete::Execute()
{
	Graph* pGraph = pControl->getGraph();
	GUI* pUI = pControl->GetUI();


	if (pGraph->get_selectedshape()) {
		//code of delete
		pGraph->update();
		pGraph->deleteShape();

		string msg = " Selected shape is deleted";
		pUI->PrintMessage(msg);
	}
	else {

		string msg = "There is no selected shape !";
		pUI->PrintMessage(msg);
	}

}