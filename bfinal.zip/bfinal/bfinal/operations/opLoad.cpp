#include "opLoad.h"

#include "..\controller.h"

#include "..\GUI\GUI.h"

opLoad::opLoad(controller* pCont) :operation(pCont) {}
opLoad::~opLoad()
{}

//Execute the operation
void opLoad::Execute()
{
	ifstream myFile("shape.txt");

	GUI* pUI = pControl->GetUI();
	pUI->load(myFile);

	Graph* pGraph = pControl->getGraph();
	pGraph->load(myFile);
	pUI->PrintMessage("GRAPH LOADED FROM 'shape.txt'");

	

}