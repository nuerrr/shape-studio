#pragma once

#include "operation.h"


class opCopy : public operation
{
public:
	opCopy(controller* pCont);
	virtual ~opCopy();

	//Add line to the controller
	virtual void Execute();

};
