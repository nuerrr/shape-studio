#pragma once

#include "operation.h"

class opChangeColor : public operation
{
public:
	opChangeColor(controller* pCont);
	virtual ~opChangeColor();

	//Add line to the controller
	virtual void Execute();

};
