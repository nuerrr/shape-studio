#pragma once

#include "operation.h"

class opSelect : public operation
{
public:
	opSelect(controller* pCont);
	virtual ~opSelect();

	// Execute selection operation
	virtual void Execute();
};