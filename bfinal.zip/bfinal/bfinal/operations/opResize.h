#pragma once

#include "operation.h"

class opResize : public operation
{
	int resize_factor;
public:
	opResize(controller* pCont);
	virtual ~opResize();

	// Execute selection operation
	virtual void Execute();
};