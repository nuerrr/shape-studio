#pragma once

#include "operation.h"

class opRedo : public operation
{
public:
	opRedo(controller* pCont);
	virtual ~opRedo();

	//Add rectangle to the controller
	virtual void Execute();

};