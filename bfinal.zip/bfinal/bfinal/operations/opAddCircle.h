#pragma once

#include "operation.h"


class opAddCircle : public operation
{
public:
	opAddCircle(controller* pCont);
	virtual ~opAddCircle();

	//Add line to the controller
	virtual void Execute();

};
