#include "opMove.h"

#include "..\controller.h"

#include "..\GUI\GUI.h"
#include<cmath>


opMove::opMove(controller* pCont) :operation(pCont)
{}
opMove::~opMove()
{}


void opMove::Execute()
{
	Point center, P2;

	//Get a Pointer to the Input / Output Interfaces 
	GUI* pUI = pControl->GetUI();
	Graph* pGraph = pControl->getGraph();
	window* pWind = pUI->Get_wind();


	if (pGraph->get_selectedshape()) {

		pUI->PrintMessage("MOVE STARTES HOLD YOUR MOUSE TO MOVE");
		int x, y;
		button btMouse= LEFT_BUTTON;
		buttonstate Bstate;
		int z = 0;
		int refresh=0;
		do {
			while (z == 0) {
				Bstate=pWind->GetButtonState(btMouse, x, y);
				if (Bstate == BUTTON_DOWN) {
					z = 1;
				}
			}
			do {
				pGraph->get_selectedshape()->Move({ x,y });
				Bstate = pWind->GetButtonState(btMouse, x, y);
				
				pGraph->Draw(pUI);
				refresh++;
				
				
			} while (Bstate == BUTTON_DOWN);

		} while (x == 1);

	}
	else
		pUI->PrintMessage("NO SELECTED SHAPE");

	

}


