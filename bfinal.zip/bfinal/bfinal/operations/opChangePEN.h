#pragma once

#include "operation.h"



class opChangePEN : public operation
{
public:
	opChangePEN(controller* pCont);
	virtual ~opChangePEN();

	//Add line to the controller
	virtual void Execute();

};

