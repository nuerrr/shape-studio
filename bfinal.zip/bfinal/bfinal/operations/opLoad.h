#pragma once

#include "operation.h"

class opLoad : public operation
{
public:
	opLoad(controller* pCont);
	virtual ~opLoad();

	//Add rectangle to the controller
	virtual void Execute();

};

