#include "opExit.h"

#include "..\controller.h"

#include "..\GUI\GUI.h"

#include <fstream>

//nou

opExit::opExit(controller* pCont) : operation(pCont) {}

opExit::~opExit() {}

void opExit::Execute()
{
	Graph* pGraph = pControl->getGraph();
	GUI* pUI = pControl->GetUI();

	ofstream myFile("shape.txt");

	pUI->save(myFile);
	pGraph->Save(myFile);
	pGraph->exit();

}

